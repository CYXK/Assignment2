package JSoup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class JSoup2014302580198 {
	static String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie";
	public static void main(String[] args) throws IOException{
		List<String> list = new ArrayList<String>();
		//��ȡ�ͽ���HTMLҳ��
		Document doc = Jsoup.connect(url).get();
        System.out.println();
        //���ݱ�ǩ��������ɸѡ
        Elements links2 = doc.getElementsByTag("h3");		//����
        String name = new String();
        for (Element link : links2) {
            String linkText = link.text();
            System.out.println(linkText);
            name = linkText;
            }
        Elements links = doc.getElementsByTag("p");			//���
        String tel = new String();
        String email = new String();
        for (Element link : links) {
        	//���������ʽ��׽�绰������
        	Pattern pattern1 = Pattern.compile("[0-9]{3}-[0-9]{8}");  
        	Pattern pattern2 = Pattern.compile("[a-z]{6}@[a-z]{3}.[a-z]{3}.[a-z]{2}"); 
        	String linkText = link.text();
        	list.add(linkText);
        	System.out.println(linkText);
        	Matcher matcher1 = pattern1.matcher(linkText);
        	Matcher matcher2 = pattern2.matcher(linkText);
        		if(matcher1.find()){
        			tel = matcher1.group();
        		}
        		if(matcher2.find()){
        			email = matcher2.group();
        		}
        }
        //ɾ�������еĿհ���
        Iterator<String>  iterator = list.iterator();
        while(iterator.hasNext()) {
        	 String str = iterator.next();
        	 if(str.equals("")){
        		 iterator.remove();
        	 }
        }
        //��ӡlist�е�����
        for(String str:list){
        	System.out.println(str);
        }
        //���TXT�ļ�
        File file  = new File("caijie.txt");
        FileWriter fw = new FileWriter(file);
        //���ı��ļ�������ʽ�༭
        fw.write(name+",�人��ѧ"+list.get(0).substring(0, 8)+"\r\n"+list.get(0).substring(8, 22)+"\r\n"+list.get(0).substring(23, 29)+tel+"\r\n"+list.get(0).substring(51, 58)+email+"\r\n"+"�������о�����:"+"\r\n"+list.get(1)+"\r\n"+list.get(2)+"\r\n"+list.get(3)+"\r\n"+list.get(4)+"\r\n"+list.get(5)+"\r\n"+"�о���������Ȥ:"+"\r\n"+list.get(6)+"\r\n");
        fw.flush();
        fw.close();
	}
}
